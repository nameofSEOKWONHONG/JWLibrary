﻿
namespace JWLibrary.Core.DB.MSSQL
{
  public interface IDataBinder<T>
  {
    T DataBind();
  }
}
